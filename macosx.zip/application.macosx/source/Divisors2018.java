import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.math.*; 
import java.util.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Divisors2018 extends PApplet {

DivInfo[] divs = new DivInfo[1012]; 
int currentNum;

public void setup() {
  
  background(0);
  currentNum = 1;
  for (int i=0; i<divs.length; i++) {
    divs[i] = new DivInfo(i);
  }
}

public void draw() {
  //noCursor();
  background(0);
  fill(0xff323247);
  noStroke();
  rect(0, 0, width, 75);
  fill(0xffE3DBB6);
  stroke(255);

  textAlign(LEFT);
  textSize(21);
  text("1001 Integers: Divisors & More", 20, 22);
  textSize(10);
  text("by Ramona Chae", 23, 36); 
  //rtext("Factorial: " + divs[currentNum].factorial(currentNum), 23, 66);
  //text("Next Prime: " + divs[currentNum].nextPrime(currentNum), 23, 60);
  textSize(9);
  fill(127);
  noStroke();
  rect(0, 175, width, 20);
  textAlign(CENTER);
  fill(0);
  text("Controls: Click and drag on the number line or use left or right arrow keys. Up and down keys increases or decreases number by 12. Inspired by numberempire.com", width/2, 189);


  textSize(50); 
  fill(10);
  text(currentNum, 407, 57);
  textSize(50); 
  fill(0xffBABACF);
  text(currentNum, 405, 55);

  // This Prime
  textSize(10); 
  fill(0xffBABACF);
  text("This prime: " + divs[currentNum].primeList.get(currentNum), 405, 68);
  //if(currentNum > 1){
  //  textAlign(LEFT);
  //  text("Previous prime: " + divs[currentNum].primeList.get(currentNum-1) + " | Next Prime: " + divs[currentNum].primeList.get(currentNum+1), 20, 65);
  //}

  //println(str());

  textSize(9);
  textAlign(LEFT);
  fill(0xffE3DBB6);
  text("Binary: " + binary(currentNum, 12), 475, 20);
  text("Hexadecimal: " + hex(currentNum, 4), 475, 35);
  text("Square: " + sq(currentNum), 475, 50);
  text("Square Root: " + sqrt(currentNum), 475, 65);

  text("Arc Tangent: " + atan(currentNum), 600, 20);
  text("Sine of Angle: " + sin(radians(PApplet.parseFloat(currentNum))), 600, 35);
  text("Cosine of Angle: " + cos(radians(PApplet.parseFloat(currentNum))), 600, 50);
  text("Logarithm: " + log(PApplet.parseFloat(currentNum)), 600, 65);

  text("Base 4 Quaternary: " + divs[currentNum].convert(currentNum, 4), 743, 20);
  text("Base 5 Quinary: " + divs[currentNum].convert(currentNum, 5), 743, 35);
  text("Base 6 Senary: " + divs[currentNum].convert(currentNum, 6), 743, 50);
  text("Base 7 Septenary: " + divs[currentNum].convert(currentNum, 7), 743, 65);


  text("Base 8 Octal: " + divs[currentNum].convert(currentNum, 8), 865, 20);
  text("Base 9 Nonary: " + divs[currentNum].convert(currentNum, 9), 865, 35);
  text("Base 11 Undecimal: " + divs[currentNum].convert(currentNum, 11), 865, 50);
  text("Base 12 Duodecimal: " + divs[currentNum].convert(currentNum, 12), 865, 65);

  fill(66);
  rect(0, 75, width, 40);
  //fill(#E3DBB6);
  //line(0, 100, width, 100);
  stroke(255, 0, 0);
  strokeWeight(3);
  fill(0xffE3DBB6);
  line(currentNum, 95, currentNum, 105);
  textAlign(LEFT);
  strokeWeight(1);
  stroke(0xffE3DBB6);
  line(0, 100, width, 100);
  for (int i = 0; i<width; i+=25) {
    strokeWeight(1);
    stroke(0xffE3DBB6);
    line(i, 95, i, 105);
    textSize(8);
    textAlign(CENTER);
    text(i, i, 90);
  }

  textSize(14);
  textAlign(LEFT);
  if (divs[currentNum].getDivs(currentNum).contains("1 2 3 4 5 6 7 ")) {
    fill(255, 0, 0);
    text("Divisors: " + divs[currentNum].getDivs(currentNum), 50, 140);
  } else if (divs[currentNum].getDivs(currentNum).contains("1 2 3 4 5 6 ")) {
    fill(255, 165, 0);
    text("Divisors: " + divs[currentNum].getDivs(currentNum), 50, 140);
  } else if (divs[currentNum].getDivs(currentNum).contains("1 2 3 4 5 ")) {
    fill(0, 255, 0);
    text("Divisors: " + divs[currentNum].getDivs(currentNum), 50, 140);
  } else if (divs[currentNum].getDivs(currentNum).contains("1 2 3 4 ") || divs[currentNum].getDivs(currentNum).contains("1 2 3 4 ")) {
    fill(255, 255, 0);
    text("Divisors: " + divs[currentNum].getDivs(currentNum), 50, 140);
  } else {
    fill(0xffE3DBB6);
    text("Divisors: " + divs[currentNum].getDivs(currentNum), 50, 140);
  }
  //text("Divisors: " + divs[currentNum].divs, 50, 140);
  fill(0xffE3DBB6);
  text("Factors: " + divs[currentNum].getFactors(currentNum), 50, 165);
  if ((float)divs[currentNum].divSum(currentNum)/currentNum > 1.89f) {
    fill(255, 0, 0);
  } else {
    fill(0xffE3DBB6);
  }
  text("Divisors Total: " + divs[currentNum].divSum(currentNum) + " | Ratio 1 : " + (float)divs[currentNum].divSum(currentNum)/currentNum, 250, 165);
  text("Divisors Total Including Itself: " + divs[currentNum].divSum2(currentNum) + " | Ratio 1 : " + (float)divs[currentNum].divSum2(currentNum)/currentNum, 560, 165);

  textSize(8);
  textAlign(CENTER);
  //Draw the Regular reference
  //if (divs[currentNum].isHamming(currentNum)) {
  if (divs[currentNum].getDivs(currentNum).contains(" 2 ") || divs[currentNum].getDivs(currentNum).contains(" 3 ") || divs[currentNum].getDivs(currentNum).contains(" 5 ")) {
    fill(0xffE3DBB6);
    noStroke();
    ellipse(150, 40, 25, 25); 
    fill(0);
    text("Reg", 150, 43);
  } else {
    noFill();
    stroke(0xffBABACF);
    ellipse(150, 40, 25, 25);  
    fill(0xffBABACF);
    text("Reg", 150, 43);
  }
  // Draw the prime reference
  if (divs[currentNum].isPrime(currentNum)) {
    fill(0xffE3DBB6);
    noStroke();
    ellipse(180, 40, 25, 25);
    fill(0);
    text("Prime", 180, 43);
  } else {
    noFill();
    stroke(0xffBABACF);
    ellipse(180, 40, 25, 25);

    fill(0xffBABACF);
    text("Prime", 180, 43);
  }
  // Draw the fib reference
  if (divs[currentNum].isFibonacci(currentNum)) {
    fill(0xffE3DBB6);
    noStroke();
    ellipse(210, 40, 25, 25); 
    fill(0);
    text("Fib", 210, 43);
  } else {
    noFill();
    stroke(0xffBABACF);
    ellipse(210, 40, 25, 25);  
    fill(0xffBABACF);
    text("Fib", 210, 43);
  }
  // Draw the perfect number reference
  if (divs[currentNum].divSum(currentNum) == currentNum) {
    fill(0xffE3DBB6);
    noStroke();
    ellipse(240, 40, 25, 25); 
    fill(0);
    text("Perfect", 240, 43);
  } else {
    noFill();
    stroke(0xffBABACF);
    ellipse(240, 40, 25, 25);  
    fill(0xffBABACF);
    text("Perfect", 240, 43);
  }

  //Draw the Catalan reference
  if (divs[currentNum].isCatalan(currentNum)) {
    fill(0xffB6B6E3);
    noStroke();
    ellipse(270, 40, 25, 25); 
    fill(0);
    text("Cat", 270, 43);
  } else {
    noFill();
    stroke(0xffBABACF);
    ellipse(270, 40, 25, 25);  
    fill(0xffBABACF);
    text("Cat", 270, 43);
  }
  //Draw the Bell reference
  if (divs[currentNum].isBell(currentNum)) {
    fill(0xffB6B6E3);
    noStroke();
    ellipse(300, 40, 25, 25); 
    fill(0);
    text("Bell", 300, 43);
  } else {
    noFill();
    stroke(0xffBABACF);
    ellipse(300, 40, 25, 25);  
    fill(0xffBABACF);
    text("Bell", 300, 43);
  }
}

public void keyPressed() {
  if (key == CODED) {
    if (keyCode == UP && currentNum < 987) {
      currentNum+=12;
    } else if (keyCode == DOWN && currentNum >12) {
      currentNum-=12;
    } else if (keyCode == RIGHT && currentNum < 1001) {
      currentNum++;
    } else if (keyCode == LEFT && currentNum > 0) {
      currentNum--;
    }
  }
}

public void mousePressed() {
  // Draw the number info
  if (mouseX >= 0 && mouseY > 75 && mouseX < width && mouseY<115) {
    currentNum = mouseX;
  }
}
public void mouseDragged() {
  if (mouseX >= 0 && mouseY > 75 && mouseX < width && mouseY<115) {
    currentNum = mouseX;
  }
}


class DivInfo {
  int num;
  ArrayList<Integer> primeList;
  private int[] catalan;
  private int[] bell;
  String nextPrime = "";
  String prevPrime = "";


  DivInfo(int num) {
    this.num = num;
    allPrimesLessThanN(8000);
    catalan = new int[10];
    bell = new int[10]; 
    catalan = makeCatalan();
    bellGenerator();
  }

  // Returns divisors
  public String getDivs(int num) {
    String result = "";
    for (int i=1; i<=num; i++) {
      if (num%i==0) {
        result+=i+" ";
      }
    }
    return result;
  }

  // Returns factors
  public String getFactors(int num) {
    String result = "";
    for (int f = 2; f*f <= num; f++) {
      while (num % f == 0) {
        result+=f + " "; 
        num/=f;
      }
    }
    return result = result  + num;
  }

  // Returns sum of divisors (traditional)
  public int divSum(int num) {
    int result = 0;
    for (int i=2; i<=sqrt(num); i++) {
      if (num%i==0) {
        if (i==(num/i))
          result += i;
        else
          result += (i + num/i);
      }
    }
    return (result + 1);
  }

  // returns divisor sum with itself
  public int divSum2(int num) {
    int result = 0;
    for (int i=2; i<=sqrt(num); i++) {
      if (num%i==0) {
        if (i==(num/i))
          result += i;
        else
          result += (i + num/i);
      }
    }
    return (result + 1 + num);
  }

  // Returns prime 
  public boolean isPrime(int num) { 
    int squarert = PApplet.parseInt(sqrt(num)) + 1; 
    for (int i = 2; i < squarert; i++) { 
      if (num % i == 0) {
        return false;
      }
    } 
    return true;
  }

  // Returns a customizable base number equivilant
  public String convert ( int number, int base )
  {
    return convert(number, base, 0, "" );
  }

  private String convert ( int number, int base, int position, String result )
  {
    char symbols[] = new char[] { '0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T' };

    if ( number < Math.pow(base, position + 1) )
    {
      return symbols[(number / (int)Math.pow(base, position))] + result;
    } else
    {
      int remainder = (number % (int)Math.pow(base, position + 1));
      return convert (  number - remainder, base, position + 1, symbols[remainder / (int)( Math.pow(base, position) )] + result );
    }
  }
  //String convert(int num, int base) {
  //  int q = num / base;
  //  int rem = num % base;

  //  if (q == 0) {
  //    return Integer.toString(rem);
  //  } else {
  //    return convert(q, base) + Integer.toString(rem);
  //  }
  //}

  // Fibonacci Numbers
  public boolean isFibonacci(int num) {
    int fib1 = 0;
    int fib2 = 1;
    do {
      int saveFib1 = fib1;
      fib1 = fib2;
      fib2 = saveFib1 + fib2;
    } while (fib2 < num);

    if (fib2 == num)
      return true;
    else
      return false;
  }

  // Catalan Numbers
  /**Generates a list of the first 10 Catalan numbers
   * 
   * @return Array of first 10 Catalan numbers
   */
  public int[] makeCatalan() {
    int[] returnVal = new int[10];

    for (int i=1; i<11; i++) {
      returnVal[i-1]= Integer.valueOf(factorial(2*i).divide(factorial(i+1).multiply(factorial(i))).toString());
    }

    return returnVal;
  }
  /**Tests to see if a number is a Catalan Number
   * Definition here : https://en.wikipedia.org/wiki/Catalan_number
   * 
   * @param n Number to test if Catalan
   * @return Whether or not a number is a Catalan #
   */
  public boolean isCatalan(int n) {
    for (int i : catalan) {
      if (i==n) return true;
    }
    return false;
  }

  /**Tests to see if a given paramater is a Hamming number
   * Hamming number if the only prime factors of that number are 2, 3, or 5
   * 
   * @param n Number to test if a Hamming Number
   * @return if the Number is a Hamming Number
   */
  public boolean isHamming(int n) {
    int num = n;
    while (num%5==0) {
      num=num/5;
    }
    while (num%3==0) {
      num=num/3;
    }

    while (num % 2==0) {
      num=num/2;
    }
    if (num==1) {
      return true;
    } else {
      return false;
    }
  }

  // Returns the instance of the prime that is looked up
  public void allPrimesLessThanN(int n) {
    primeList = new ArrayList();
    for (int i = 1; i <= n; i ++) {
      if (isPrime(i))
        primeList.add(i);
    }
  }

  public BigInteger factorial(int n) {
    BigInteger convertToRet = new BigInteger("1");
    for (int i=1; i<=n; i++) {
      convertToRet = convertToRet.multiply(new BigInteger(String.valueOf(i)));
    }
    return convertToRet;
  }

  public void bellGenerator() {
    bell[0] = 1;
    bell[1] = 1;
    for (int i=2; i<bell.length; i++) {
      bell[i] = recurrBell(i);
    }
  }

  public int nComb(int n, int k) {
    BigInteger result;
    result = factorial(n).divide(factorial(k).multiply(factorial(n-k)));

    return result.intValue();
  }

  public int recurrBell(int n) {
    int sum = 0;
    for (int i=0; i<n; i++) {
      sum += nComb(n-1, i)*bell[i];
    }
    return sum;
  }

  public boolean isBell(int n) {
    for (int i : bell) {
      if (i==n) return true;
    }
    return false;
  }

  // Returns the previous prime
  public int nextPrime(int num) {
    int retval = 0;
    if (isPrime(num)) {
      retval=primeList.get(num);
      return retval;
    } else {
      retval=primeList.get(num-1);
      return retval;
    }
  }
}
  public void settings() {  size(1001, 195); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Divisors2018" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
